# Circalify Production Templates

10 production-ready templates demonstrating real-world use cases for circular timeline visualizations.

Each template is a complete, self-contained HTML file that works by simply opening it in a browser. All templates use realistic sample data and thoughtful color schemes matched to their purpose.

## Templates

### 1. Quarterly Business Planning
**File:** `01-quarterly-business-planning.html`

Track strategic goals and key milestones across all four quarters of the year. Includes:
- 4 quarterly sections with distinct color-coded rings
- Cross-quarter strategic initiatives
- Sample goals for each quarter (market research, product development, launch, growth)
- Perfect for executive dashboards and board presentations

**Use Cases:** Business planning, OKR tracking, quarterly reviews, strategic planning

---

### 2. Product Launch Roadmap
**File:** `02-product-launch-roadmap.html`

Visualize the complete product launch journey from pre-launch through post-launch phases. Includes:
- Pre-launch phase (3 months preparation)
- Launch phase (intensive 2-month window)
- Post-launch phase (6 months scaling)
- Critical path milestones and team activities

**Use Cases:** Product management, go-to-market planning, launch coordination, timeline visualization

---

### 3. Editorial Calendar
**File:** `03-editorial-calendar.html`

Plan and track diverse content publishing across multiple channels and formats. Includes:
- 5 content rings: Blog posts, Videos, Podcasts, Case Studies, Webinars
- 12 months of editorial planning
- Multiple posts/content per month
- Balanced content distribution

**Use Cases:** Content marketing, editorial planning, blog scheduling, media production planning

---

### 4. Multi-Project Timeline
**File:** `04-project-timeline.html`

Manage 4 major projects running in parallel with integrated phases. Includes:
- 4 concurrent projects with different timelines
- Overlapping phases (planning, development, testing, launch)
- Cross-project initiatives and shared resources
- Example: Alpha (Jan-Aug), Beta (Mar-Oct), Gamma (May-Dec), Delta (Jun-Nov)

**Use Cases:** Portfolio management, multi-project coordination, resource planning, timeline dependency analysis

---

### 5. Marketing Campaign Calendar
**File:** `05-marketing-campaign-calendar.html`

Multi-channel marketing campaigns with seasonal promotions and paid advertising. Includes:
- 5 marketing channels: Email, Social Media, Paid Ads, Content, Events
- Seasonal campaigns (New Year, Spring, Summer, Back-to-School, Black Friday, Holiday)
- Continuous baseline activities with promotional peaks
- Campaign overlap visualization

**Use Cases:** Marketing planning, campaign calendars, channel coordination, promotional planning

---

### 6. Academic Year Planner
**File:** `06-academic-year-planner.html`

Complete academic calendar with semesters, exams, holidays, and events. Includes:
- Spring semester (Jan-Apr) and Fall semester (Sep-Dec)
- Midterm and final exam periods
- Holiday breaks and makeup days
- Projects, assignments, presentations, and campus events

**Use Cases:** Student planning, institution scheduling, academic calendars, course management

---

### 7. Event Planning Timeline
**File:** `07-event-planning-timeline.html`

Complete event lifecycle from planning through post-event follow-up. Includes:
- Planning phase (6 months before)
- Promotion phase (3-4 months before)
- Execution phase (final weeks and event day)
- Logistics phase (venue, catering, AV, permits)
- Post-event phase (thank you, feedback, content, reporting)

**Use Cases:** Event management, conference planning, wedding planning, corporate events, product launches

---

### 8. HR Annual Cycle
**File:** `08-hr-annual-cycle.html`

Comprehensive human resources annual calendar with all major HR functions. Includes:
- Recruitment cycles and hiring windows
- Compensation reviews and salary adjustments
- Learning & development programs and workshops
- Employee engagement events and team building
- Wellness programs and health initiatives

**Use Cases:** HR planning, recruitment scheduling, employee development, benefits administration, company culture

---

### 9. Financial Year Overview
**File:** `09-financial-year-overview.html`

Complete financial cycle with budgeting, reporting, audits, and compliance. Includes:
- Annual budget planning and approvals
- Monthly, quarterly, and annual financial reports
- Internal and external audit schedules
- Period closing procedures
- Tax preparation and regulatory filings

**Use Cases:** Financial planning, accounting calendars, audit schedules, CFO dashboards, compliance tracking

---

### 10. Personal Goal Tracker
**File:** `10-personal-goal-tracker.html`

Track personal goals across multiple life areas throughout the year. Includes:
- 5 goal categories: Fitness, Learning, Projects, Habits, Wellness
- Year-round commitments (daily habits, wellness)
- Seasonal goals and milestones
- Project timelines and learning courses
- Personal challenges and achievement tracking

**Use Cases:** Personal development, goal tracking, New Year's resolutions, life planning, habit formation

---

## Quick Start

1. **Open any template** - Just open the HTML file in your browser
2. **No setup required** - All templates use the CDN version of Circalify
3. **Customize** - Edit the JavaScript data sections to customize with your own content
4. **Export** - Take screenshots for presentations or documentation

## Customization Guide

Each template can be easily customized:

### Colors
Change colors by modifying the color values in the `timeline.setData()` calls:
```javascript
{ label: 'Event Name', startDate: '2025-01-15', endDate: '2025-01-15', color: '#YOUR_COLOR' }
```

### Events/Milestones
Add or remove events by editing the arrays in each `setData()` call:
```javascript
timeline.setData([
    { label: 'Your Event', startDate: '2025-MM-DD', endDate: '2025-MM-DD' },
    // Add more...
], 'Ring Name');
```

### Timeframe
Change the year or duration by modifying the timeline configuration:
```javascript
const timeline = new CircularTimeline('#timeline', {
    startYear: 2025,        // Change year
    numberOfMonths: 12,     // Show more/fewer months
    startMonth: 0,          // Start from different month
    // ... other options
});
```

### Styling
Modify the gradient backgrounds, font sizes, and layout by editing the CSS `<style>` section at the top of each file.

## Technical Details

- **Framework:** Vanilla JavaScript + SVG
- **Dependencies:** Zero (Circalify handles all heavy lifting)
- **File Size:** 20-30KB per template (minified HTML)
- **Browser Support:** All modern browsers (Chrome, Firefox, Safari, Edge)
- **Responsive:** All templates adapt to mobile and tablet screens
- **Interactive:** Hover effects and click handlers enabled by default

## API Reference

All templates use the Circalify API with these key methods:

```javascript
// Create timeline
const timeline = new CircularTimeline(selector, config);

// Add events to a data ring
timeline.setData(events, 'Ring Name');

// Get all rings
const rings = timeline.getRings();

// Cleanup
timeline.destroy();
```

See the [Circalify README](../../README.md) for complete API documentation.

## Tips for Best Results

1. **Keep Labels Short** - Shorter event labels display better in the timeline
2. **Use Consistent Colors** - Group related events with similar colors
3. **Date Precision** - Use specific dates (YYYY-MM-DD format) for accurate positioning
4. **Realistic Data** - Use actual timelines from your organization
5. **Print-Friendly** - Most templates work well when printed to PDF
6. **Mobile Testing** - All templates are mobile-responsive
7. **Accessibility** - All templates include semantic HTML and ARIA labels

## Real-World Applications

### Business & Management
- Strategic planning and OKR tracking
- Portfolio and project management
- Product roadmap visualization
- Resource allocation and capacity planning

### Marketing & Sales
- Campaign planning and execution
- Content calendar management
- Sales cycle visualization
- Event and promotion scheduling

### Operations
- Annual budget cycles
- Audit and compliance schedules
- HR recruiting and onboarding
- Maintenance and upgrade windows

### Education & Training
- Academic year planning
- Learning program schedules
- Course development timelines
- Curriculum planning

### Personal & Wellness
- Goal setting and tracking
- Habit formation
- Personal project planning
- Work-life balance visualization

## Contributing

Found an issue or want to suggest improvements? Please open an issue on the [Circalify GitHub repository](https://github.com/MahmoodSeoud/circalify).

## License

All templates are licensed under the MIT License - the same as Circalify itself.

---

**Ready to use?** Start with the template that matches your use case and customize it with your own data!
